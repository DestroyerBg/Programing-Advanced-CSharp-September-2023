﻿namespace GenericScale
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            EqualityScale<int> equal = new EqualityScale<int>(5, 6);
            Console.WriteLine(equal.AreEqual());
        }
    }
}